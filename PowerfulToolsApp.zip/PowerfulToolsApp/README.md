# Powerful Tools Android App

Native Kotlin + Jetpack Compose starter app.

## Open
Open the `PowerfulToolsApp` folder in Android Studio and let Gradle sync.

## Build
Use Android Studio's Build > Make Project, or run:
`./gradlew assembleDebug`

## Default demo password
`888`

Change `accessPassword` in `MainActivity.kt` before publishing.

## Included
Password generator, UUID generator, Base64 encoder, JSON formatter, text counter,
random number generator, Telegram Bot API helper, search, copy-to-clipboard, dark Material UI.

package com.umarcodex.powerfultools

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import kotlin.random.Random

data class Tool(val name: String, val category: String, val action: String)

private val tools = listOf(
    Tool("Password Generator", "Security", "Generate a strong random password."),
    Tool("UUID Generator", "Developer", "Generate a random UUID."),
    Tool("Base64 Encode", "Developer", "Encode text to Base64."),
    Tool("JSON Formatter", "Developer", "Format JSON text."),
    Tool("Text Counter", "Text", "Count characters and words."),
    Tool("Random Number", "Utilities", "Generate a random number."),
    Tool("Telegram Bot API Helper", "Telegram", "Build a Bot API endpoint safely.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PowerfulToolsApp() }
    }
}

@Composable
fun PowerfulToolsApp() {
    var unlocked by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    val accessPassword = "888" // Change before release.

    if (!unlocked) {
        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.padding(24.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Text("🛠️ Powerful Tools", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Enter the app password")
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(password, { password = it }, label = { Text("Password") })
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        unlocked = password == accessPassword
                    }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
                    if (password.isNotEmpty() && password != accessPassword) {
                        Text("Incorrect password", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        return
    }

    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Tool?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("🛠️ Powerful Tools") }) }
        ) { pad ->
            if (selected == null) {
                Column(Modifier.padding(pad).padding(16.dp)) {
                    Text("Developer • Utilities • Telegram • Security", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Search tools") }
                    )
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(tools.filter { it.name.contains(query, true) || it.category.contains(query, true) }) { tool ->
                            Card(onClick = { selected = tool }, modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(tool.name, style = MaterialTheme.typography.titleMedium)
                                    Text(tool.category, style = MaterialTheme.typography.labelMedium)
                                    Text(tool.action)
                                }
                            }
                        }
                    }
                }
            } else {
                ToolScreen(selected!!, onBack = { selected = null })
            }
        }
    }
}

@Composable
fun ToolScreen(tool: Tool, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    Column(Modifier.padding(16.dp).fillMaxSize()) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(tool.name, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(tool.action)
        Spacer(Modifier.height(16.dp))

        when (tool.name) {
            "Password Generator" -> {
                Button(onClick = { output = randomPassword(20) }) { Text("Generate") }
            }
            "UUID Generator" -> {
                Button(onClick = { output = java.util.UUID.randomUUID().toString() }) { Text("Generate") }
            }
            "Random Number" -> {
                Button(onClick = { output = Random.nextInt(0, 1_000_000).toString() }) { Text("Generate") }
            }
            "Base64 Encode" -> {
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("Text") })
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    output = android.util.Base64.encodeToString(input.toByteArray(), android.util.Base64.NO_WRAP)
                }) { Text("Encode") }
            }
            "Text Counter" -> {
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("Text") })
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    val words = input.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size
                    output = "Characters: ${input.length}\nWords: $words"
                }) { Text("Count") }
            }
            "JSON Formatter" -> {
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), minLines = 5,
                    label = { Text("JSON") })
                Spacer(Modifier.height(8.dp))
                Button(onClick = { output = simpleJsonFormat(input) }) { Text("Format") }
            }
            "Telegram Bot API Helper" -> {
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(),
                    label = { Text("Bot token") })
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    output = if (input.isBlank()) "Enter a bot token." else
                        "https://api.telegram.org/bot$input/getMe"
                }) { Text("Build getMe URL") }
            }
        }

        if (output.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(output)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        clipboard.setText(AnnotatedString(output))
                    }) { Text("Copy") }
                }
            }
        }
    }
}

private fun randomPassword(length: Int): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*"
    return buildString { repeat(length) { append(chars[Random.nextInt(chars.length)]) } }
}

private fun simpleJsonFormat(json: String): String {
    var indent = 0
    val out = StringBuilder()
    var quoted = false
    for (c in json.trim()) {
        when (c) {
            '"' -> { quoted = !quoted; out.append(c) }
            '{', '[' -> {
                out.append(c)
                if (!quoted) { indent++; out.append('\n').append("  ".repeat(indent)) }
            }
            '}', ']' -> {
                if (!quoted) { indent--; out.append('\n').append("  ".repeat(indent)) }
                out.append(c)
            }
            ',' -> {
                out.append(c)
                if (!quoted) out.append('\n').append("  ".repeat(indent))
            }
            ':' -> { out.append(c); if (!quoted) out.append(' ') }
            else -> if (c != '\n' && c != '\r' && c != '\t') out.append(c)
        }
    }
    return out.toString()
}
